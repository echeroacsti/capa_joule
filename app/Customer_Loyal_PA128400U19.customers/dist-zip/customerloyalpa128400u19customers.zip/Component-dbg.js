sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("CustomerLoyalPA128400U19.customers.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);